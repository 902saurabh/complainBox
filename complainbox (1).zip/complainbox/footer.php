<footer class="footer footer-default">
    <div class="container">
        <!-- <nav class="float-left">
           <ul>
             <li>
               <a >
                Complain Box
               </a>
             </li>
             <li>
               <a href="#">
                 About Us
               </a>
             </li>
             <li>
               <a href="#">
                 Blog
               </a>
             </li>
             <li>
               <a href="#">
                 Licenses
               </a>
             </li>
           </ul>
         </nav>-->
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear() + " KJSCE, All Rights Reserved.");
            </script>
            Made by
            <a href="https://kjsce.somaiya.edu/kjsce" target="_blank">KJSCE Somaiya</a>.
        </div>
    </div>
</footer>
 